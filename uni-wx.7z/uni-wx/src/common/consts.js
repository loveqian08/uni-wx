export const SCORES_URL = 'https://preapp.ymbank.com/market-resources';
