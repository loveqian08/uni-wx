import { dateFormat } from '@/common/utils/utils.js';

module.exports = function (time, mode) {
  return dateFormat(time, mode);
};